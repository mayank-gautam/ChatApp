package com.mayank.gautam99.chatapp.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.mayank.gautam99.chatapp.databinding.ActivityPhoneNumberBinding;

import org.jetbrains.annotations.NotNull;

import java.util.concurrent.TimeUnit;

public class PhoneNumberActivity extends AppCompatActivity {

    private ActivityPhoneNumberBinding binding;
    FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        auth = FirebaseAuth.getInstance();

        if(auth.getCurrentUser() != null){
            startActivity(new Intent(PhoneNumberActivity.this,MainActivity.class));
            finish();
        }

        binding = ActivityPhoneNumberBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!binding.etPhoneNumber.getText().toString().isEmpty()){
                    if(binding.etPhoneNumber.getText().toString().trim().length()==10){
                        Intent intent = new Intent(PhoneNumberActivity.this,OtpActivity.class);
                        intent.putExtra("PhoneNumber","+91"+binding.etPhoneNumber.getText().toString());
                        startActivity(intent);
                    }else{
                        Toast.makeText(PhoneNumberActivity.this, "Invalid Phone number", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(PhoneNumberActivity.this, "Please Enter Phone number", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}