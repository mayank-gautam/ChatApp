package com.mayank.gautam99.chatapp.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.mayank.gautam99.chatapp.Modals.User;
import com.mayank.gautam99.chatapp.databinding.ActivitySetupProfileBinding;

public class SetupProfileActivity extends AppCompatActivity {

    ActivitySetupProfileBinding binding;
    FirebaseAuth auth;
    FirebaseStorage storage;
    FirebaseDatabase database;
    final int imageProfileRequestCode = 1;
    Uri selectedImageUri;
    ProgressDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySetupProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        dialog = new ProgressDialog(this);
        dialog.setMessage("Updating Profile...");
        dialog.setCancelable(false);


        auth = FirebaseAuth.getInstance();
        storage = FirebaseStorage.getInstance();
        database = FirebaseDatabase.getInstance();

        setProfileImage();
        putDataOnFirebase();



    }

    private void putDataOnFirebase() {
        binding.setProfileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String profileName = binding.etProfileName.getText().toString();

                if(profileName.isEmpty()){
                    Toast.makeText(SetupProfileActivity.this, "Please Enter your name", Toast.LENGTH_SHORT).show();
                    return;
                }

                dialog.show();
                if(selectedImageUri != null){
                    StorageReference reference = storage.getReference().child("Profiles").child(auth.getUid());
                    reference.putFile(selectedImageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                            if(task.isSuccessful()){
                                reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        String imageUrl = uri.toString();
                                        String phoneNumber = auth.getCurrentUser().getPhoneNumber();
                                        String name = binding.etProfileName.getText().toString();
                                        String uid = auth.getUid();

                                        User user = new User(name,uid,phoneNumber,imageUrl);

                                        database.getReference().child("users").child(uid).setValue(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void unused) {
                                                dialog.dismiss();
                                                startActivity(new Intent(SetupProfileActivity.this,MainActivity.class));
                                                finish();
                                            }
                                        });
                                    }
                                });
                            }
                        }
                    });
                }else {
                    String phoneNumber = auth.getCurrentUser().getPhoneNumber();
                    String name = binding.etProfileName.getText().toString();
                    String uid = auth.getUid();

                    User user = new User(name,uid,phoneNumber,"No Image");

                    database.getReference().child("users").child(uid).setValue(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            dialog.dismiss();
                            startActivity(new Intent(SetupProfileActivity.this,MainActivity.class));
                            finish();
                        }
                    });
                }

            }
        });
    }

    private void setProfileImage() {
        binding.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent,imageProfileRequestCode);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(data != null){
            if(data.getData() != null){
                binding.imageView.setImageURI(data.getData());
                selectedImageUri = data.getData();
            }
        }

    }
}