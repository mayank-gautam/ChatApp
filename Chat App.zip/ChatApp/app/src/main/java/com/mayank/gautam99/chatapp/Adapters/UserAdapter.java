package com.mayank.gautam99.chatapp.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mayank.gautam99.chatapp.Activities.ChatActivity;
import com.mayank.gautam99.chatapp.R;
import com.mayank.gautam99.chatapp.Modals.User;
import com.mayank.gautam99.chatapp.databinding.RawDataBinding;

import org.jetbrains.annotations.NotNull;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {
    ArrayList<User> userArrayList;
    Context context;

    public UserAdapter(ArrayList<User> userArrayList, Context context) {
        this.userArrayList = userArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.raw_data,parent,false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        User currUser = userArrayList.get(position);

        String senderId = FirebaseAuth.getInstance().getUid();
        String senderRoom = senderId+currUser.getUid();

        FirebaseDatabase.getInstance().getReference()
                .child("chats")
                .child(senderRoom)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                        if(snapshot.exists()) {
                            String lastMsg = snapshot.child("lastMessage").getValue(String.class);
                            long  time = snapshot.child("lastMsgTime").getValue(Long.class);

                            @SuppressLint("SimpleDateFormat") SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm:a");
                            holder.binding.tvLastMessageTimeRaw.setText(simpleDateFormat.format(new Date(time)));
                            holder.binding.tvLastMessageRaw.setText(lastMsg);
                        }else{
                            holder.binding.tvLastMessageRaw.setText("Tap to chat");
                            holder.binding.tvLastMessageTimeRaw.setText("");

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull @NotNull DatabaseError error) {

                    }
                });

        holder.binding.tvUserNameRaw.setText(currUser.getName());


        Glide.with(context).load(currUser.getProfileImage()).placeholder(R.drawable.default_profile_img)
                .into(holder.binding.userProfileRaw);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ChatActivity.class);
                intent.putExtra("name",currUser.getName());
                intent.putExtra("image",currUser.getProfileImage());
                intent.putExtra("receiverUid",currUser.getUid());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return userArrayList.size();
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        RawDataBinding binding;
        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = RawDataBinding.bind(itemView);
        }
    }
}
