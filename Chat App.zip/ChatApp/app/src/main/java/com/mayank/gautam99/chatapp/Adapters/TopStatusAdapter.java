package com.mayank.gautam99.chatapp.Adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.mayank.gautam99.chatapp.Activities.MainActivity;
import com.mayank.gautam99.chatapp.Modals.Status;
import com.mayank.gautam99.chatapp.Modals.UserStatus;
import com.mayank.gautam99.chatapp.R;
import com.mayank.gautam99.chatapp.databinding.ItemStatusBinding;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

import omari.hamza.storyview.StoryView;
import omari.hamza.storyview.callback.StoryClickListeners;
import omari.hamza.storyview.model.MyStory;

public class TopStatusAdapter extends RecyclerView.Adapter<TopStatusAdapter.TopViewHolder> {

    Context context;
    ArrayList<UserStatus> userStatuses;

    public TopStatusAdapter(Context context, ArrayList<UserStatus> userStatuses) {
        this.context = context;
        this.userStatuses = userStatuses;
    }

    @NonNull
    @NotNull
    @Override
    public TopViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_status,parent,false);
        return new TopViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull TopViewHolder holder, int position) {
        UserStatus currUserStatus = userStatuses.get(position);
        Status lastStatus = currUserStatus.getStatuses().get(currUserStatus.getStatuses().size() - 1);
        Glide.with(context).load(lastStatus.getImageUrl()).into(holder.binding.statusImage);
        holder.binding.circularStatuseView.setPortionsCount(currUserStatus.getStatuses().size());

        holder.binding.circularStatuseView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<MyStory> myStories = new ArrayList<>();

                for(Status status: currUserStatus.getStatuses()){
                    myStories.add(new MyStory(
                            status.getImageUrl()
                    ));
                }



                new StoryView.Builder(((MainActivity)context).getSupportFragmentManager())
                        .setStoriesList(myStories) // Required
                        .setStoryDuration(5000) // Default is 2000 Millis (2 Seconds)
                        .setTitleText(currUserStatus.getName()) // Default is Hidden
                        .setSubtitleText("") // Default is Hidden
                        .setTitleLogoUrl(currUserStatus.getProfileImage()) // Default is Hidden
                        .setStoryClickListeners(new StoryClickListeners() {
                            @Override
                            public void onDescriptionClickListener(int position) {
                                //your action
                            }

                            @Override
                            public void onTitleIconClickListener(int position) {
                                //your action
                            }
                        }) // Optional Listeners
                        .build() // Must be called before calling show method
                        .show();
            }
        });


    }

    @Override
    public int getItemCount() {
        return userStatuses.size();
    }

    public static class TopViewHolder extends RecyclerView.ViewHolder {
        ItemStatusBinding binding;
        public TopViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            binding = ItemStatusBinding.bind(itemView);
        }
    }
}
