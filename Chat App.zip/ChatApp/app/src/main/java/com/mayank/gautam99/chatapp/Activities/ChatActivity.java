package com.mayank.gautam99.chatapp.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.mayank.gautam99.chatapp.Adapters.MessagesAdapter;
import com.mayank.gautam99.chatapp.Modals.Message;
import com.mayank.gautam99.chatapp.R;
import com.mayank.gautam99.chatapp.databinding.ActivityChatBinding;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Objects;

public class ChatActivity extends AppCompatActivity {

    ActivityChatBinding binding;
    MessagesAdapter adapter;
    ArrayList<Message> messageArrayList;
    String senderRoom, receiverRoom;
    String senderUid,receiverUid,name;
    FirebaseDatabase database;
    FirebaseStorage storage;
    private final int imageSendCode = 10;
    ProgressDialog dialog;
    Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        messageArrayList = new ArrayList<>();


        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();

         name = getIntent().getStringExtra("name");
        String profileImage = getIntent().getStringExtra("image");
         receiverUid = getIntent().getStringExtra("receiverUid");
         senderUid = FirebaseAuth.getInstance().getUid();

        senderRoom = senderUid+receiverUid;
        receiverRoom = receiverUid+senderUid;

//        Objects.requireNonNull(getSupportActionBar()).setDisplayShowTitleEnabled(false);
        binding.userName.setText(name);
        Glide.with(this).load(profileImage)
                .placeholder(R.drawable.default_profile_img)
                .into(binding.profileImage);
        binding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        handler = new Handler();
        isReceiverOnline();

        isTyping();


        adapter = new MessagesAdapter(this,messageArrayList,senderRoom,receiverRoom);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setAdapter(adapter);


        setDataOnUI();
        msgSend();
        sendImage();
        progressDialog();

    }

    private void isTyping() {
        binding.edMessageBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                database.getReference().child("presence").child(senderUid).setValue("Typing...");
                handler.removeCallbacksAndMessages(null);
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        database.getReference().child("presence").child(senderUid).setValue("Online");
                    }
                },1000);
            }
        });
    }

    //    offline when activity close

    @Override
    protected void onPause() {
        super.onPause();
        String currId = FirebaseAuth.getInstance().getUid();
        database.getReference().child("presence").child(currId).setValue("Offline");
    }


    private void isReceiverOnline() {
        database.getReference().child("presence").child(receiverUid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    String status = snapshot.getValue(String.class);
                    if(status!=null && !status.isEmpty()){
                        if(status.equals("Offline")){
                            binding.onelineStatus.setVisibility(View.GONE);
                        }else {
                            binding.onelineStatus.setText(status);
                            binding.onelineStatus.setVisibility(View.VISIBLE);
                        }
                    }


                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }

    private void progressDialog(){
        dialog = new ProgressDialog(this);
        dialog.setCancelable(false);
        dialog.setMessage("Image uploading...");
    }



    private void sendImage() {
        binding.attechmentChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent,imageSendCode);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==imageSendCode){
            if(data != null && data.getData()  != null){
                Uri selectPath = data.getData();
                Calendar calendar = Calendar.getInstance();
                StorageReference reference = storage.getReference().child("chats").child(""+calendar.getTimeInMillis());
                dialog.show();
                reference.putFile(selectPath).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<UploadTask.TaskSnapshot> task) {
                        dialog.dismiss();
                        if(task.isSuccessful()){
                            reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    String filePath = uri.toString();
                                    sendData(filePath);

//                                    Toast.makeText(ChatActivity.this, filePath, Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                });
            }
        }
    }

    private void setDataOnUI() {
        database.getReference().child("chats")
                .child(senderRoom)
                .child("message")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull  DataSnapshot snapshot) {
                        messageArrayList.clear();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                            Message message = dataSnapshot.getValue(Message.class); // Type casing
                            message.setMessageId(dataSnapshot.getKey());
                            messageArrayList.add(message);
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull  DatabaseError error) {

                    }
                });

    }

    //    online status
    @Override
    protected void onResume() {
        super.onResume();
        String currId = FirebaseAuth.getInstance().getUid();
        database.getReference().child("presence").child(currId).setValue("Online");
    }

    private void msgSend() {
        binding.sendChatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData(null);
            }
        });
    }

    private void sendData( String filePath) {
        String messageText = binding.edMessageBox.getText().toString();
        Date date = new Date();

        Message message = new Message(messageText,senderUid,date.getTime());
        if(filePath != null) {
            message.setImageUrl(filePath);
            message.setMessage("photo");
        }
        binding.edMessageBox.setText("");
        String randomKey = database.getReference().push().getKey(); // push build a unique node

        HashMap<String,Object> lastMsgObj = new HashMap<>();
        lastMsgObj.put("lastMessage",message.getMessage());
        lastMsgObj.put("lastMsgTime",date.getTime());

        database.getReference().child("chats").child(senderRoom).updateChildren(lastMsgObj);
        database.getReference().child("chats").child(receiverRoom).updateChildren(lastMsgObj);


        assert randomKey != null;
        database.getReference().child("chats")
                .child(senderRoom)
                .child("message")
                .child(randomKey)
                .setValue(message).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                database.getReference().child("chats")
                        .child(receiverRoom)
                        .child("message")
                        .child(randomKey)
                        .setValue(message).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {

                    }
                });
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}