package com.mayank.gautam99.chatapp.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.mayank.gautam99.chatapp.Adapters.TopStatusAdapter;
import com.mayank.gautam99.chatapp.Modals.Status;
import com.mayank.gautam99.chatapp.Modals.UserStatus;
import com.mayank.gautam99.chatapp.R;
import com.mayank.gautam99.chatapp.Modals.User;
import com.mayank.gautam99.chatapp.Adapters.UserAdapter;
import com.mayank.gautam99.chatapp.databinding.ActivityMainBinding;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    FirebaseDatabase database;
    UserAdapter userAdapter;
    TopStatusAdapter topStatusAdapter;
    ArrayList<User> userArrayList;
    ProgressDialog progressDialog;
    ArrayList<UserStatus> userStatusesAl;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        showProgressDilog("Chat Loading...");
        binding.userListRecyclerView.showShimmerAdapter();
//        binding.statusListRecyclerView.showShimmerAdapter();

        database = FirebaseDatabase.getInstance();
        userArrayList = new ArrayList<>();
        userStatusesAl = new ArrayList<>();
        userAdapter = new UserAdapter(userArrayList,this);
        topStatusAdapter = new TopStatusAdapter(this,userStatusesAl);


        getData();
        setStatus();
        getCurrentUser();
        putAllStatusIntoArrayList();


        binding.userListRecyclerView.setAdapter(userAdapter);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        binding.statusListRecyclerView.setLayoutManager(linearLayoutManager);

//        binding.statusListRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true)); // it does reverse
        binding.statusListRecyclerView.setAdapter(topStatusAdapter);


    }

    private void putAllStatusIntoArrayList() {
        database.getReference().child("stories").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    userStatusesAl.clear();
                    for(DataSnapshot storiesSnapshot : snapshot.getChildren()){
                        UserStatus userStatus = new UserStatus();
                        userStatus.setName(storiesSnapshot.child("name").getValue(String.class));
                        userStatus.setProfileImage(storiesSnapshot.child("profileImage").getValue(String.class));
                        userStatus.setLastUpdate(storiesSnapshot.child("lastUpdated").getValue(Long.class));

                        ArrayList<Status> statuses = new ArrayList<>();

                        for(DataSnapshot statusSnapshot : storiesSnapshot.child("statuses").getChildren()) {
                            Status sampleStatus = statusSnapshot.getValue(Status.class);
                            statuses.add(sampleStatus);
                        }
                        userStatus.setStatuses(statuses);
                        userStatusesAl.add(userStatus);
                    }

                    binding.statusListRecyclerView.setVisibility(View.VISIBLE);
                    topStatusAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }

    private void getCurrentUser() {
        database.getReference().child("users").child(FirebaseAuth.getInstance().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                        user = snapshot.getValue(User.class);

                    }

                    @Override
                    public void onCancelled(@NonNull @NotNull DatabaseError error) {

                    }
                });

    }

    private void setStatus() {
        binding.bottomNavbar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @SuppressLint("NonConstantResourceId")
            @Override
            public boolean onNavigationItemSelected(@NonNull @NotNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.statusMenu:
                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_GET_CONTENT);
                        startActivityForResult(intent,16);
                        break;
                }
                return false;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(data != null) {
            if (data.getData() != null) {
                showProgressDilog("Story updating...");
                FirebaseStorage storage = FirebaseStorage.getInstance();
                Date date = new Date();
                StorageReference reference = storage.getReference().child("status").child("" + date.getTime());
                reference.putFile(data.getData()).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<UploadTask.TaskSnapshot> task) {
                        if (task.isSuccessful()) {
                            reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    UserStatus userStatus = new UserStatus();
                                    userStatus.setName(user.getName());
                                    userStatus.setProfileImage(user.getProfileImage());
                                    userStatus.setLastUpdate(date.getTime());

                                    HashMap<String, Object> obj = new HashMap<>();
                                    obj.put("name",userStatus.getName());
                                    obj.put("profileImage",userStatus.getProfileImage());
                                    obj.put("lastUpdated",userStatus.getLastUpdate());

                                    database.getReference().child("stories").child(FirebaseAuth.getInstance().getUid())
                                            .updateChildren(obj);

                                    String imageUrl = uri.toString();
                                    Status status = new Status(imageUrl,userStatus.getLastUpdate());

                                    database.getReference().child("stories")
                                            .child(FirebaseAuth.getInstance().getUid())
                                            .child("statuses")
                                            .push()
                                            .setValue(status);



                                    progressDialog.dismiss();
                                }
                            });
                        }
                    }
                });
            }
        }

    }

    private void showProgressDilog(String msg) {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(msg);
        progressDialog.setCancelable(false);
        progressDialog.show();
    }

    private void getData() {

        database.getReference().child("users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                userArrayList.clear();
                for (DataSnapshot snapshot1 : snapshot.getChildren()){
                    User user = snapshot1.getValue(User.class);
                    if(!user.getUid().equals(FirebaseAuth.getInstance().getUid()))
                        userArrayList.add(user);
                }

                userAdapter.notifyDataSetChanged();
                progressDialog.dismiss();
//                binding.userListRecyclerView.hideShimmerAdapter();
//                Log.i("shi","line 238");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.groups:
                startActivity(new Intent(this,GroupChatActivity.class));
                break;
            case R.id.signOut:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(this,PhoneNumberActivity.class));
                finishAffinity();
        }
        return super.onOptionsItemSelected(item);
    }

//    online status
    @Override
    protected void onResume() {
        super.onResume();
        String currId = FirebaseAuth.getInstance().getUid();
        database.getReference().child("presence").child(currId).setValue("Online");
    }

    @Override
    protected void onPause() {
        super.onPause();
        String currId = FirebaseAuth.getInstance().getUid();
        database.getReference().child("presence").child(currId).setValue("Offline");
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.top_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
}