package com.mayank.gautam99.chatapp.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.github.pgreze.reactions.ReactionPopup;
import com.github.pgreze.reactions.ReactionsConfig;
import com.github.pgreze.reactions.ReactionsConfigBuilder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mayank.gautam99.chatapp.Modals.Message;
import com.mayank.gautam99.chatapp.Modals.User;
import com.mayank.gautam99.chatapp.R;
import com.mayank.gautam99.chatapp.databinding.ReceiverGroupLayoutBinding;
import com.mayank.gautam99.chatapp.databinding.ReceiverLayoutBinding;
import com.mayank.gautam99.chatapp.databinding.SenderGroupLayoutBinding;
import com.mayank.gautam99.chatapp.databinding.SenderLayoutBinding;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Objects;

public class GroupCharMessagesAdapter extends RecyclerView.Adapter{

    Context context;
    ArrayList<Message> messageArrayList;

    final int ITEM_SEND = 1;
    final int ITEM_RECEIVE = 2;



    public GroupCharMessagesAdapter() {
    }

    public GroupCharMessagesAdapter(Context context, ArrayList<Message> messageArrayList) {
        this.context = context;
        this.messageArrayList = messageArrayList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if(viewType==ITEM_SEND){
            View view = LayoutInflater.from(context).inflate(R.layout.sender_group_layout,parent,false);
            return new SendViewHolder(view);
        }else{
            View view = LayoutInflater.from(context).inflate(R.layout.receiver_group_layout,parent,false);
            return new ReceiverViewHolder(view);
        }
    }

    @Override
    public int getItemViewType(int position) {
        Message message = messageArrayList.get(position);

        if(Objects.requireNonNull(FirebaseAuth.getInstance().getUid()).equals(message.getSenderId())){
            return ITEM_SEND;
        }else{
            return ITEM_RECEIVE;
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Message message = messageArrayList.get(position);
        int[] reaction = new int[]{
                R.drawable.ic_fb_like,
                R.drawable.ic_fb_love,
                R.drawable.ic_fb_laugh,
                R.drawable.ic_fb_wow,
                R.drawable.ic_fb_sad,
                R.drawable.ic_fb_angry
        };

//        create feeling
        ReactionsConfig config = new ReactionsConfigBuilder(context)
                .withReactions(reaction)
                .build();

// feeling popup
        ReactionPopup popup = new ReactionPopup(context, config, (pos) -> {
            if(pos>=0 && pos<=5) {
                if (holder.getClass() == SendViewHolder.class) {
                    SendViewHolder viewHolder = (SendViewHolder) holder;

                    viewHolder.binding.feeling.setImageResource(reaction[pos]);
                    viewHolder.binding.feeling.setVisibility(View.VISIBLE);

                } else {
                    ReceiverViewHolder viewHolder = (ReceiverViewHolder) holder;
                    viewHolder.binding.feeling.setImageResource(reaction[pos]);
                    viewHolder.binding.feeling.setVisibility(View.VISIBLE);
                }

                message.setFeeling(pos);
//    Set feeling in chat firebase
                FirebaseDatabase.getInstance().getReference()
                        .child("public")
                        .child(message.getMessageId()).setValue(message);
            }

            return true; // true is closing popup, false is requesting a new selection
        });




        if(holder.getClass()==ReceiverViewHolder.class){
            ReceiverViewHolder viewHolder = (ReceiverViewHolder) holder;

            if(message.getMessage().equals("photo")){
                viewHolder.binding.receiverImageView.setVisibility(View.VISIBLE);
                viewHolder.binding.msgRecive.setVisibility(View.GONE);
                Glide.with(context).load(message.getImageUrl())
                        .placeholder(R.drawable.placeholder_image).into(viewHolder.binding.receiverImageView);
            }

            FirebaseDatabase.getInstance().getReference()
                    .child("users").child(message.getSenderId()).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                    if(snapshot.exists()){
                        User user = snapshot.getValue(User.class);
                        viewHolder.binding.userName.setText("@" +user.getName());
                    }
                }

                @Override
                public void onCancelled(@NonNull @NotNull DatabaseError error) {

                }
            });

            viewHolder.binding.msgRecive.setText(message.getMessage());

            if(message.getFeeling()>=0){
                // Show feeling in ui
                viewHolder.binding.feeling.setImageResource(reaction[message.getFeeling()]);
                viewHolder.binding.feeling.setVisibility(View.VISIBLE);
            }else{
                viewHolder.binding.feeling.setVisibility(View.GONE);
            }


            viewHolder.binding.msgRecive.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    popup.onTouch(v,event);
                    return false;
                }
            });

            viewHolder.binding.receiverImageView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    popup.onTouch(v,event);
                    return false;
                }
            });
        }else{
            SendViewHolder viewHolder = (SendViewHolder) holder;
            if(message.getMessage().equals("photo")){
                viewHolder.binding.sendImageView.setVisibility(View.VISIBLE);
                viewHolder.binding.msgSend.setVisibility(View.GONE);
                Glide.with(context).load(message.getImageUrl())
                        .placeholder(R.drawable.placeholder_image).into(viewHolder.binding.sendImageView);
            }

            FirebaseDatabase.getInstance().getReference()
                    .child("users").child(message.getSenderId()).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                    if(snapshot.exists()){
                        User user = snapshot.getValue(User.class);
                        viewHolder.binding.userName.setText("@" +user.getName());
                    }
                }

                @Override
                public void onCancelled(@NonNull @NotNull DatabaseError error) {

                }
            });

            viewHolder.binding.msgSend.setText(message.getMessage());
            if(message.getFeeling()>=0){
                viewHolder.binding.feeling.setImageResource(reaction[message.getFeeling()]);
                viewHolder.binding.feeling.setVisibility(View.VISIBLE);
            }else{
                viewHolder.binding.feeling.setVisibility(View.GONE);
            }

//            image felling set
            viewHolder.binding.msgSend.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    popup.onTouch(v,event);
                    return false;
                }
            });

            viewHolder.binding.sendImageView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    popup.onTouch(v,event);
                    return false;
                }
            });
        }
    }


    @Override
    public int getItemCount() {
        return messageArrayList.size();
    }



    public static class SendViewHolder extends RecyclerView.ViewHolder{

        SenderGroupLayoutBinding binding;
        public SendViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = SenderGroupLayoutBinding.bind(itemView);
        }
    }

    public static class ReceiverViewHolder extends RecyclerView.ViewHolder{

        ReceiverGroupLayoutBinding binding;
        public ReceiverViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ReceiverGroupLayoutBinding.bind(itemView);
        }
    }
}
